#!/usr/bin/env python3
"""
Pipeline для рекомендаций продуктов и генерации push-уведомлений.

Как использовать:
  python client_recommendation_pipeline.py --data_dir data --output recommendations.csv [--config config.json]

Ожидаемая структура папки data:
 - clients.csv
 - client_1_transactions_3m.csv, client_2_transactions_3m.csv, ...
 - client_1_transfers_3m.csv, client_2_transfers_3m.csv, ...
 - (опционально) exchange_rates.csv с колонками: currency,rate_to_kzt

Реализовано:
 - чтение csv (все файлы с "transactions" и "transfer"/"transfers")
 - нормализация категорий
 - конвертация валют по файлу курсов (если есть). Если курса нет — помечаем FX-операции
 - агрегирование метрик по клиенту (за последние 3 месяца относительно max даты в датасете)
 - расчет ожидаемой выгоды (в ₸/мес) для набора продуктов по правилам, описанным в техзадании
 - выбор лучшего продукта с учетом пригодности и бизнес-приоритета
 - генерация push-уведомления по шаблону с форматированием сумм
 - экспорт CSV с колонками: client_code,product,push_notification
 - логирование причин выбора (reason_codes)

Примечание: в файле есть конфиг-словарь `DEFAULT_CONFIG`, его можно заменить аргументом --config.
"""

import os
import glob
import argparse
import json
from datetime import datetime
from typing import Dict, Any, List, Tuple, Optional

import pandas as pd
import numpy as np

# ----------------------------- Конфиг по умолчанию -----------------------------
DEFAULT_CONFIG: Dict[str, Any] = {
    "months_window": 3,
    "travel_cashback_rate": 0.04,
    "premium_base_rate": 0.02,
    "premium_tier_1_rate": 0.03,
    "premium_tier_2_rate": 0.04,
    "premium_tier_1_min_balance": 1_000_000,
    "premium_tier_2_min_balance": 6_000_000,
    "premium_min_balance": 300_000,
    "premium_cashback_limit": 100_000,
    "credit_top3_rate": 0.10,
    "credit_installment_bonus_per_large_purchase": 2_000,
    "credit_large_purchase_threshold": 50_000,
    "fx_spread_saving_estimate": 0.01,
    "fx_monthly_threshold_kzt": 50_000,
    "deposit_rates": {
        "multicurrency_annual": 0.145,
        "savings_annual": 0.165,
        "accumulation_annual": 0.155
    },
    "deposit_min_free_funds": 100_000,
    "investment_monthly_conservative_return": 0.005,
    "investment_min_entry": 6,
    "travel_min_threshold_kzt": 30_000,
    "tie_breaker_priority": [
        "Премиальная карта",
        "Депозит",
        "Карта для путешествий",
        "Кредитная карта",
        "FX",
        "Инвестиции",
        "Кредит наличными",
        "Золото"
    ],
    # шаблоны пушей (можно расширять)
    "push_templates": {
        "Карта для путешествий": "{name}, в {month} вы потратили на поездки {travel_sum} ₸. С тревел-картой часть расходов вернулась бы ≈{benefit} ₸. Открыть карту в приложении.",
        "Премиальная карта": "{name}, средний остаток {avg_balance} ₸ и траты в ресторанах {restaurant_sum} ₸. Премиальная карта даст повышенный кешбэк ≈{benefit} ₸. Подключить?",
        "Кредитная карта": "{name}, ваши топ‑категории дают кешбэк ≈{benefit} ₸/мес и рассрочку на крупные покупки. Узнать доступный лимит?",
        "FX": "{name}, у вас {num_fx} валютных операций на {fx_sum} {fx_currencies}. Через FX в приложении можно экономить ≈{benefit} ₸/мес. Посмотреть курс?",
        "Депозит": "{name}, свободных средств примерно {free_funds} ₸. При вкладе под {rate_percent}% годовых доход ≈{benefit} ₸/мес. Оформить вклад?",
        "Инвестиции": "{name}, у вас свободно {free_funds} ₸. Инвестиционный портфель с консервативной доходностью ≈{benefit} ₸/мес. Начать инвестировать?",
        "Кредит наличными": "{name}, замечены сигналы на потребность в кредитe. Хотите узнать индивидуальное предложение?",
        "Золото": "{name}, вы активно хеджируете риски. Покупка золота может помочь в долгосрочной защите капитала. Посмотреть предложения?"
    },
    "push_max_length": 220
}

# ----------------------------- Вспомогательные структуры -----------------------------
# Простейшая нормализация категорий (пример). Пользователь может расширить словарь.
CATEGORY_MAP = {
    # travel
    "Поезда": "travel",
    "Самолёты": "travel",
    "Авиабилеты": "travel",
    "Такси": "travel",
    "Отели": "travel",
    "АЗС": "transport_fuel",
    # premium bonus cats
    "Ювелирные украшения": "premium_bonus",
    "Косметика": "premium_bonus",
    "Парфюмерия": "premium_bonus",
    "Кафе": "restaurants",
    "Рестораны": "restaurants",
    # online services
    "Доставка": "online_services",
    "Игры": "online_services",
    "Кино": "online_services",
    "Подписки": "online_services",
    # cash operations
    "Снятие наличных": "atm_withdrawal",
    "ATM": "atm_withdrawal",
    "Пополнение": "deposit_in",
    # investments / gold
    "Покупка золота": "gold",
    "Продажа золота": "gold",
    "Invest": "invest",
}

TRAVEL_CATEGORIES = {"travel", "transport_fuel", "restaurants"}
PREMIUM_BONUS_CATEGORIES = {"premium_bonus", "restaurants"}
ONLINE_SERVICES_CATEGORIES = {"online_services"}
ATM_CATEGORIES_SUBSTR = ["Снятие", "ATM", "наличн"]

MONTHS_RU = [
    "январе", "феврале", "марте", "апреле", "мае", "июне",
    "июле", "августе", "сентябре", "октябре", "ноябре", "декабре"
]

# ----------------------------- Утилиты -----------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Client product recommendation pipeline")
    p.add_argument("--data_dir", required=True, help="Папка с clients.csv и клиентскими CSV")
    p.add_argument("--output", required=True, help="Выходной CSV с рекомендациями")
    p.add_argument("--config", required=False, help="Опциональный JSON config путь")
    return p.parse_args()


def load_config(path: Optional[str]) -> Dict[str, Any]:
    cfg = DEFAULT_CONFIG.copy()
    if path:
        with open(path, "r", encoding="utf-8") as f:
            user_cfg = json.load(f)
        cfg.update(user_cfg)
    return cfg


def read_all_csvs(data_dir: str) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    # clients.csv
    clients_path = os.path.join(data_dir, "clients.csv")
    if not os.path.exists(clients_path):
        raise FileNotFoundError(f"Не найден clients.csv в {data_dir}")
    clients = pd.read_csv(clients_path)

    # transactions и transfers — читаем все соответствующие файлы и объединяем
    tx_files = glob.glob(os.path.join(data_dir, "*transactions*.csv")) + glob.glob(os.path.join(data_dir, "*transaction*.csv"))
    transfer_files = glob.glob(os.path.join(data_dir, "*transfer*.csv")) + glob.glob(os.path.join(data_dir, "*transfers*.csv"))

    # fallback: возможно файлы названы client_1_transactions_3m.csv или client_1_transactions.csv
    transactions = []
    for p in tx_files:
        try:
            df = pd.read_csv(p)
            transactions.append(df)
        except Exception as e:
            print(f"warning: не удалось прочитать {p}: {e}")
    transfers = []
    for p in transfer_files:
        try:
            df = pd.read_csv(p)
            transfers.append(df)
        except Exception as e:
            print(f"warning: не удалось прочитать {p}: {e}")

    if transactions:
        transactions_df = pd.concat(transactions, ignore_index=True)
    else:
        transactions_df = pd.DataFrame(columns=["date", "category", "amount", "currency", "client_code"])

    if transfers:
        transfers_df = pd.concat(transfers, ignore_index=True)
    else:
        transfers_df = pd.DataFrame(columns=["date", "type", "direction", "amount", "currency", "client_code"])

    return clients, transactions_df, transfers_df


def load_exchange_rates(data_dir: str) -> Dict[str, float]:
    # Ожидаем exchange_rates.csv с колонками currency,rate_to_kzt
    path = os.path.join(data_dir, "exchange_rates.csv")
    if not os.path.exists(path):
        return {}
    df = pd.read_csv(path)
    rates = dict(zip(df.currency.astype(str), df.rate_to_kzt.astype(float)))
    return rates


def normalize_category(cat: str) -> str:
    if pd.isna(cat):
        return "unknown"
    cat = str(cat).strip()
    if cat in CATEGORY_MAP:
        return CATEGORY_MAP[cat]
    # простая эвристика: проверяем вхождение слов
    for k, v in CATEGORY_MAP.items():
        if k.lower() in cat.lower():
            return v
    return cat.lower()


def convert_amount(row: pd.Series, rates: Dict[str, float]) -> Tuple[Optional[float], bool]:
    # Возвращает (amount_kzt_or_None, is_fx)
    cur = str(row.get("currency", "KZT")).upper()
    amt = row.get("amount", 0.0)
    try:
        amt = float(amt)
    except Exception:
        return None, False
    if cur in ("KZT", "TENGE", "₸"):
        return amt, False
    if rates and cur in rates:
        return amt * rates[cur], False
    # курс недоступен — помечаем как FX
    return amt, True


def format_kzt(x: float) -> str:
    # форматирование: пробелы между разрядами, десятичный разделитель — запятая, 0 знаков после дробной если целое
    try:
        if x is None or (isinstance(x, float) and np.isnan(x)):
            return "0"
        # округлим до целых тенге
        val = int(round(float(x)))
        s = f"{val:,}".replace(",", " ")
        return s
    except Exception:
        return str(x)


# ----------------------------- Агрегация и расчеты -----------------------------

def preprocess_and_filter(transactions: pd.DataFrame, transfers: pd.DataFrame, months_window: int) -> Tuple[pd.DataFrame, pd.DataFrame]:
    # Приводим даты в datetime
    for df in [transactions, transfers]:
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")

    # вычисляем max date в объединённом датасете
    all_dates = pd.concat([transactions["date"].dropna(), transfers["date"].dropna()]) if not transactions.empty or not transfers.empty else pd.Series([], dtype="datetime64[ns]")
    if all_dates.empty:
        max_date = pd.Timestamp.now()
    else:
        max_date = all_dates.max()
    start_date = max_date - pd.DateOffset(months=months_window)

    # фильтруем
    if "date" in transactions.columns:
        transactions = transactions[transactions["date"] >= start_date].copy()
    if "date" in transfers.columns:
        transfers = transfers[transfers["date"] >= start_date].copy()

    return transactions, transfers


def aggregate_client_metrics(clients: pd.DataFrame,
                             transactions: pd.DataFrame,
                             transfers: pd.DataFrame,
                             rates: Dict[str, float],
                             cfg: Dict[str, Any]) -> pd.DataFrame:
    # Нормализация категорий
    transactions = transactions.copy()
    transactions["category_norm"] = transactions["category"].apply(normalize_category) if "category" in transactions.columns else "unknown"

    # Конвертация валют и пометка FX (на транзакциях + трансферах)
    def convert_row_amounts(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        out_amounts = []
        out_is_fx = []
        for _, r in df.iterrows():
            amt_kzt, is_fx = convert_amount(r, rates)
            out_amounts.append(amt_kzt)
            out_is_fx.append(is_fx)
        df["amount_kzt"] = out_amounts
        df["is_fx"] = out_is_fx
        return df

    transactions = convert_row_amounts(transactions) if not transactions.empty else transactions
    transfers = convert_row_amounts(transfers) if not transfers.empty else transfers

    # Объединяем потоки трат (transactions + transfers where direction=out) для вычисления расходов
    tx_out = transactions.copy()
    # Некоторые transfers имеют колонку direction
    transfers_out = transfers[transfers.get("direction", "out") == "out"].copy() if not transfers.empty else pd.DataFrame()

    expend_df = pd.concat([tx_out, transfers_out], ignore_index=True, sort=False) if not tx_out.empty or not transfers_out.empty else pd.DataFrame()

    # Группируем по клиенту
    client_rows = []
    client_codes = clients["client_code"].unique().tolist()

    for cc in client_codes:
        client_meta = clients[clients["client_code"] == cc].iloc[0].to_dict()
        c_tx = expend_df[expend_df["client_code"] == cc] if not expend_df.empty else pd.DataFrame()
        c_tr = transfers[transfers["client_code"] == cc] if not transfers.empty else pd.DataFrame()

        # total_outflows = сумма отрицательных потоков по 'amount_kzt' (тут считаем, что amount положителен и direction=='out' определяет расход)
        total_outflows = c_tx["amount_kzt"].dropna().sum() if not c_tx.empty else 0.0
        total_inflows = 0.0
        if not transfers.empty:
            c_in = transfers[(transfers["client_code"] == cc) & (transfers.get("direction", "in") == "in")]
            total_inflows = c_in["amount_kzt"].dropna().sum() if not c_in.empty else 0.0

        num_transactions = len(c_tx) if not c_tx.empty else 0
        num_fx_ops = int(c_tx["is_fx"].sum()) if (not c_tx.empty and "is_fx" in c_tx.columns) else 0

        # monthly averages (делим на cfg['months_window'])
        months_w = cfg.get("months_window", 3)

        # spend by normalized category
        monthly_spend_by_category = {}
        if not c_tx.empty:
            cat_groups = c_tx.groupby("category_norm")["amount_kzt"].sum()
            for cat, total in cat_groups.items():
                monthly_spend_by_category[cat] = float(total) / months_w

        monthly_total_spend = float(sum([v for v in monthly_spend_by_category.values()]))

        # некоторые метрики: num_trips
        num_trips = 0
        travel_sum = 0.0
        for cat, monthly_sum in monthly_spend_by_category.items():
            if cat in TRAVEL_CATEGORIES:
                num_trips += int((c_tx[c_tx["category_norm"] == cat].shape[0]))
                travel_sum += monthly_sum

        # atm withdrawals
        num_atm_withdrawals = 0
        if not c_tx.empty:
            for substr in ATM_CATEGORIES_SUBSTR:
                num_atm_withdrawals += int(c_tx["category"].astype(str).str.contains(substr, case=False, na=False).sum())

        # fx monthly non-kzt spend
        fx_currencies = c_tx[c_tx["is_fx"] == True]["currency"].unique().tolist() if not c_tx.empty and "is_fx" in c_tx.columns else []
        fx_sum_monthly = float(c_tx[c_tx["is_fx"] == True]["amount"].astype(float).sum() / months_w) if (not c_tx.empty and "is_fx" in c_tx.columns) else 0.0

        avg_balance = float(client_meta.get("avg_monthly_balance_KZT", 0.0) if client_meta.get("avg_monthly_balance_KZT") is not None else 0.0)
        # free funds: avg_balance - avg monthly spend
        free_funds = avg_balance - monthly_total_spend

        # last date to compute month name
        last_date = None
        all_dates = pd.concat([c_tx.get("date", pd.Series([], dtype="datetime64[ns]")), c_tr.get("date", pd.Series([], dtype="datetime64[ns]"))]) if (not c_tx.empty or not c_tr.empty) else pd.Series([], dtype="datetime64[ns]")
        if not all_dates.empty:
            last_date = all_dates.max()
        else:
            last_date = pd.Timestamp.now()

        client_rows.append({
            "client_code": int(cc),
            "name": client_meta.get("name", ""),
            "status": client_meta.get("status", ""),
            "age": client_meta.get("age", None),
            "city": client_meta.get("city", None),
            "avg_balance": avg_balance,
            "monthly_total_spend": monthly_total_spend,
            "monthly_spend_by_category": monthly_spend_by_category,
            "num_trips": num_trips,
            "travel_monthly_sum": travel_sum,
            "num_fx_ops": num_fx_ops,
            "fx_currencies": fx_currencies,
            "fx_sum_monthly_original_currency": fx_sum_monthly,
            "free_funds": free_funds,
            "num_atm_withdrawals": num_atm_withdrawals,
            "num_transactions": num_transactions,
            "last_date": last_date
        })

    return pd.DataFrame(client_rows)


# ----------------------------- Оценка продуктов -----------------------------

def score_products_for_client(row: pd.Series, cfg: Dict[str, Any]) -> Tuple[Dict[str, Dict[str, Any]], List[str]]:
    # возвращает словарь product -> {expected_value, eligible(bool), reason_codes(list)}
    res = {}
    reasons = []

    # вспомогательные переменные
    monthly_total = row.get("monthly_total_spend", 0.0)
    travel_monthly = row.get("travel_monthly_sum", 0.0)
    num_trips = int(row.get("num_trips", 0))
    avg_balance = float(row.get("avg_balance", 0.0))
    monthly_by_cat = row.get("monthly_spend_by_category", {}) or {}
    num_fx = int(row.get("num_fx_ops", 0))
    fx_sum_original = float(row.get("fx_sum_monthly_original_currency", 0.0))
    free_funds = float(row.get("free_funds", 0.0))
    num_atm = int(row.get("num_atm_withdrawals", 0))
    num_transactions = int(row.get("num_transactions", 0))

    # ---------- Карта для путешествий ----------
    travel_relevant = travel_monthly
    travel_expected = travel_relevant * cfg.get("travel_cashback_rate", 0.04)
    travel_eligible = (num_trips >= 2) or (travel_relevant > cfg.get("travel_min_threshold_kzt", 30_000))
    travel_reasons = []
    if travel_eligible:
        travel_reasons.append("TRAVEL_HIGH_SPEND")
    res["Карта для путешествий"] = {"expected_value": float(travel_expected), "eligible": travel_eligible, "reasons": travel_reasons}

    # ---------- Премиальная карта ----------
    base_rate = cfg.get("premium_base_rate", 0.02)
    tier1_min = cfg.get("premium_tier_1_min_balance", 1_000_000)
    tier2_min = cfg.get("premium_tier_2_min_balance", 6_000_000)
    if avg_balance >= tier2_min:
        applied_rate = cfg.get("premium_tier_2_rate", 0.04)
    elif avg_balance >= tier1_min:
        applied_rate = cfg.get("premium_tier_1_rate", 0.03)
    else:
        applied_rate = base_rate

    premium_base_cashback = monthly_total * base_rate
    premium_total_cashback = monthly_total * applied_rate
    premium_bonus_spend = sum([monthly_by_cat.get(cat, 0.0) for cat in PREMIUM_BONUS_CATEGORIES])
    special_rate = 0.04
    premium_bonus = premium_bonus_spend * max(0.0, (special_rate - applied_rate))

    premium_expected = min(cfg.get("premium_cashback_limit", 100_000), premium_total_cashback + premium_bonus)
    premium_eligible = (avg_balance > cfg.get("premium_min_balance", 300_000)) or (num_atm > 3)
    premium_reasons = []
    if avg_balance > cfg.get("premium_min_balance", 300_000):
        premium_reasons.append("HIGH_BALANCE")
    if num_atm > 3:
        premium_reasons.append("FREQUENT_ATM")
    res["Премиальная карта"] = {"expected_value": float(premium_expected), "eligible": premium_eligible, "reasons": premium_reasons}

    # ---------- Кредитная карта ----------
    # Находим top3 категории по monthly_by_cat
    sorted_cats = sorted(monthly_by_cat.items(), key=lambda x: x[1], reverse=True)
    top3 = [v for _, v in sorted_cats[:3]]
    credit_cashback = sum(top3) * cfg.get("credit_top3_rate", 0.10)
    online_spend = sum([monthly_by_cat.get(cat, 0.0) for cat in ONLINE_SERVICES_CATEGORIES])
    credit_cashback += online_spend * cfg.get("credit_top3_rate", 0.10)
    # бонус за крупные покупки
    large_purchases = 0
    if num_transactions > 0:
        # ищем реальные крупные операции в месячном датасете — грубая оценка: смотрим на transactions не на monthly_by_cat
        large_purchases = int(sum([1 for v in monthly_by_cat.values() if v > cfg.get("credit_large_purchase_threshold", 50_000)]))
    credit_cashback += large_purchases * cfg.get("credit_installment_bonus_per_large_purchase", 2000)
    credit_eligible = large_purchases > 0
    credit_reasons = []
    if large_purchases > 0:
        credit_reasons.append("LARGE_PURCHASES")
    res["Кредитная карта"] = {"expected_value": float(credit_cashback), "eligible": credit_eligible, "reasons": credit_reasons}

    # ---------- FX (обмен валют) ----------
    fx_expected = num_fx * (fx_sum_original * cfg.get("fx_spread_saving_estimate", 0.01)) if num_fx > 0 else 0.0
    fx_eligible = (num_fx >= 1) or (fx_sum_original > cfg.get("fx_monthly_threshold_kzt", 50_000))
    fx_reasons = ["FX_ACTIVE"] if fx_eligible else []
    res["FX"] = {"expected_value": float(fx_expected), "eligible": fx_eligible, "reasons": fx_reasons}

    # ---------- Кредит наличными (рекомендация осторожно) ----------
    loan_eligible = False
    loan_reasons = []
    # Здесь можем проверить наличие в monthly_by_cat погашений/loan_payment_out — для примера смотрим по ключу 'loan' или 'loan_payment'
    if any(k for k in monthly_by_cat.keys() if "loan" in k or "погаш" in k):
        loan_eligible = True
        loan_reasons.append("HAS_LOAN_PAYMENTS")
    # отрицательный free funds как триггер
    if free_funds < -50_000:
        loan_eligible = True
        loan_reasons.append("NEGATIVE_CASHFLOW")
    res["Кредит наличными"] = {"expected_value": 0.0, "eligible": loan_eligible, "reasons": loan_reasons}

    # ---------- Депозит ----------
    deposit_expected = 0.0
    deposit_eligible = False
    deposit_reasons = []
    if free_funds > cfg.get("deposit_min_free_funds", 100_000):
        # используем rate savings как пример
        rate = cfg.get("deposit_rates", {}).get("savings_annual", 0.165)
        deposit_expected = free_funds * (rate / 12.0)
        deposit_eligible = True
        deposit_reasons.append("HAS_FREE_FUNDS")
    res["Депозит"] = {"expected_value": float(deposit_expected), "eligible": deposit_eligible, "reasons": deposit_reasons}

    # ---------- Инвестиции ----------
    invest_expected = 0.0
    invest_eligible = False
    invest_reasons = []
    if free_funds >= cfg.get("investment_min_entry", 6):
        invest_expected = free_funds * cfg.get("investment_monthly_conservative_return", 0.005)
        invest_eligible = True
        invest_reasons.append("INVEST_POTENTIAL")
    res["Инвестиции"] = {"expected_value": float(invest_expected), "eligible": invest_eligible, "reasons": invest_reasons}

    # ---------- Золото ----------
    gold_eligible = False
    gold_reasons = []
    if any(k for k in monthly_by_cat.keys() if "gold" in k or "зол" in k):
        gold_eligible = True
        gold_reasons.append("GOLD_HISTORY")
    res["Золото"] = {"expected_value": 0.0, "eligible": gold_eligible, "reasons": gold_reasons}

    return res, row.get("name", "")


# ----------------------------- Выбор лучшего продукта -----------------------------

def select_best_product(scores: Dict[str, Dict[str, Any]], cfg: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    # отфильтровать не eligible
    eligible_products = {p: v for p, v in scores.items() if v.get("eligible", False)}
    # если ничего не подходит — допускаем некоторые продукты в fallback (Инвестиции/Депозит)
    if not eligible_products:
        fallback = "Инвестиции"
        if fallback in scores:
            return fallback, scores[fallback]
        # попробовать депозит
        if "Депозит" in scores and scores["Депозит"]["eligible"]:
            return "Депозит", scores["Депозит"]
        # иначе выбрать продукт с наибольшей ожидаемой выгоды
        best = max(scores.items(), key=lambda x: x[1].get("expected_value", 0.0))
        return best[0], best[1]

    # выбрать тот, у кого максимальная expected_value
    best_name, best_data = max(eligible_products.items(), key=lambda x: x[1].get("expected_value", 0.0))

    # если есть близкие значения внутри 10% — применяем приоритет
    best_val = best_data.get("expected_value", 0.0)
    close = {p: v for p, v in eligible_products.items() if p != best_name and abs(v.get("expected_value", 0.0) - best_val) / max(1e-9, best_val) < 0.10}
    if close:
        # выбрать по приоритету
        for p in cfg.get("tie_breaker_priority", []):
            if p in eligible_products:
                return p, eligible_products[p]
    return best_name, best_data


# ----------------------------- Генерация пуш-уведомления -----------------------------

def generate_push(client_row: pd.Series, product: str, score_data: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[str, List[str]]:
    template = cfg.get("push_templates", {}).get(product, "{name}, рекомендуем продукт: {product} — выгода ≈{benefit} ₸")
    name = client_row.get("name", "Клиент")
    last_date = client_row.get("last_date", pd.Timestamp.now())
    month_str = MONTHS_RU[last_date.month - 1] if hasattr(last_date, "month") else "последний месяц"

    # metrics для подстановки
    metrics = {
        "name": name,
        "month": month_str,
        "benefit": format_kzt(score_data.get("expected_value", 0.0)),
        "avg_balance": format_kzt(client_row.get("avg_balance", 0.0)),
        "travel_sum": format_kzt(client_row.get("travel_monthly_sum", 0.0)),
        "restaurant_sum": format_kzt(sum([client_row.get("monthly_spend_by_category", {}).get(c, 0.0) for c in ["restaurants"]])),
        "free_funds": format_kzt(client_row.get("free_funds", 0.0)),
        "rate_percent": int(round((cfg.get("deposit_rates", {}).get("savings_annual", 0.0) * 100))),
        "num_fx": client_row.get("num_fx_ops", 0),
        "fx_sum": format_kzt(client_row.get("fx_sum_monthly_original_currency", 0.0)),
        "fx_currencies": ",".join(client_row.get("fx_currencies", [])) if client_row.get("fx_currencies") else "",
        "fx_sum_kzt": format_kzt(client_row.get("fx_sum_monthly_original_currency", 0.0)),
        "product": product
    }

    push = template.format(**metrics)

    # длина и правила: проверка на max length
    max_len = cfg.get("push_max_length", 220)
    if len(push) > max_len:
        # постараемся сократить уточняющую часть (последнее предложение)
        sentences = push.split('.')
        if len(sentences) > 1:
            short_push = '.'.join(sentences[:1]).strip()
            if len(short_push) <= max_len:
                push = short_push + '.'
            else:
                push = push[:max_len - 3].rstrip() + '...'
        else:
            push = push[:max_len - 3].rstrip() + '...'

    # ensure one emoji max and one exclamation
    # простая фильтрация — не добавляем эмодзи автоматически

    # reason codes
    reasons = score_data.get("reasons", [])

    return push, reasons


# ----------------------------- Основной flow -----------------------------

def run_pipeline(data_dir: str, output: str, config_path: Optional[str] = None) -> None:
    cfg = load_config(config_path)
    clients, transactions, transfers = read_all_csvs(data_dir)
    rates = load_exchange_rates(data_dir)

    # Preprocess, filter by recent months
    transactions, transfers = preprocess_and_filter(transactions, transfers, cfg.get("months_window", 3))

    # Агрегация метрик
    client_metrics_df = aggregate_client_metrics(clients, transactions, transfers, rates, cfg)

    out_rows = []
    audit_rows = []

    for _, row in client_metrics_df.iterrows():
        scores, client_name = score_products_for_client(row, cfg)
        product, score_data = select_best_product(scores, cfg)
        push_text, reasons = generate_push(row, product, score_data, cfg)

        out_rows.append({
            "client_code": int(row.get("client_code")),
            "product": product,
            "push_notification": push_text
        })

        audit_rows.append({
            "client_code": int(row.get("client_code")),
            "selected_product": product,
            "expected_value": score_data.get("expected_value", 0.0),
            "eligible": score_data.get("eligible", False),
            "reason_codes": ",".join(score_data.get("reasons", []) or reasons)
        })

    out_df = pd.DataFrame(out_rows)
    out_df.to_csv(output, index=False, encoding="utf-8", quoting=1)  # quoting=1 -> csv.QUOTE_ALL

    # Сохраняем audit для отладки
    audit_path = os.path.splitext(output)[0] + "_audit.csv"
    pd.DataFrame(audit_rows).to_csv(audit_path, index=False, encoding="utf-8")

    print(f"Готово. Рекомендации экспортированы в {output}. Аудит в {audit_path}")


if __name__ == "__main__":
    args = parse_args()
    run_pipeline(args.data_dir, args.output, args.config)
